捐赠通道：[Github Blog](https://iamr0s.github.io/post/1/)

首次刷入一定要从桌面启动，会自动申请所需要的权限。

### v2.3

更新MiShare版本至2.15.0

更新XposedMiShare代码以支持最新版本

优化权限申请代码

### v2.2

禁止混淆`mishare-sdk.jar`，解决部分闪退bug。

自动清理设备记录，解决冗余的设备列表和设备不在身边的bug。

### v2.1

修复搜索设备列表闪退

优化搜索设备界面和逻

优化代码结构

更新SDK文件

新增点击列表发送
